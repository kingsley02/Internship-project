package Practice;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class NewCase extends JFrame {
	
	private JTextField tasks;
	private JButton add;
	private DefaultListModel<String> taskListModel;
	private JList<String> taskList;
	
	public NewCase() {
		setTitle("Ton do list application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,400);
		setLocationRelativeTo(null);
		
		tasks = new JTextField();
		add   =  new JButton("Add task");
		taskListModel = new DefaultListModel<>();
		taskList = new JList<>(taskListModel);
		
		tasks.setSize(120, 200);
		JPanel panel = new JPanel();
		panel.add(add);
		panel.add(tasks);
		panel.add(taskList);
		
		JScrollPane scrollPane = new JScrollPane(taskList);
		
		add(panel,"North");
		add(scrollPane, "Center");
		
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String task = tasks.getText();
				if (!task.isEmpty())  {
					taskListModel.addElement(task);
					tasks.setText(" ");
				}
			}
		});
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new NewCase().setVisible(true);
			}
		});
		

	}

}
